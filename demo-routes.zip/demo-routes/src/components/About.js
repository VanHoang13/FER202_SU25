import React from 'react';

function About() {
  return <h1>Giới Thiệu</h1>;
}

export default About;