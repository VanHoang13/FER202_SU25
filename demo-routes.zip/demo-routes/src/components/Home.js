import React from 'react';

function Home() {
  return <h1>Trang Chủ</h1>;
}

export default Home;